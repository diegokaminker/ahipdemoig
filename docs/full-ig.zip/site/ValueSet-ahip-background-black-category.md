# AHIP Black Background Categories - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **AHIP Black Background Categories**

## ValueSet: AHIP Black Background Categories 

| | |
| :--- | :--- |
| *Official URL*:http://ahip.org/demographics/ValueSet/ahip-background-black-category | *Version*:0.1.0 |
| Active as of 2026-08-25 | *Computable Name*:AHIPBackgroundBlackCategories |
| **Copyright/Legal**: Used by permission of HL7 International, all rights reserved Creative Commons License | |

 
Used as the granular follow-up answer options shown when the patient selects Black, African, or African American on the race/ethnicity question. 

 **References** 

* [AHIP CIVITAS DEMO QUESTIONNAIRE](Questionnaire-AHIPDemoQuestionnaire.md)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "ahip-background-black-category",
  "url" : "http://ahip.org/demographics/ValueSet/ahip-background-black-category",
  "version" : "0.1.0",
  "name" : "AHIPBackgroundBlackCategories",
  "title" : "AHIP Black Background Categories",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-08-25T00:00:00-04:00",
  "publisher" : "AHIP",
  "contact" : [{
    "name" : "AHIP",
    "telecom" : [{
      "system" : "url",
      "value" : "http://ahip.org"
    }]
  }],
  "description" : "Used as the granular follow-up answer options shown when the patient selects Black, African, or African American on the race/ethnicity question.",
  "copyright" : "Used by permission of HL7 International, all rights reserved Creative Commons License",
  "compose" : {
    "include" : [{
      "system" : "urn:oid:2.16.840.1.113883.6.238",
      "concept" : [{
        "code" : "2058-6",
        "display" : "African American"
      },
      {
        "code" : "2068-5",
        "display" : "Barbadian"
      },
      {
        "code" : "2184-0",
        "display" : "Dominican"
      },
      {
        "code" : "2062-8",
        "display" : "Ethiopian"
      },
      {
        "code" : "2071-9",
        "display" : "Haitian"
      },
      {
        "code" : "2072-7",
        "display" : "Jamaican"
      },
      {
        "code" : "2063-6",
        "display" : "Liberian"
      },
      {
        "code" : "2065-1",
        "display" : "Nigerian"
      },
      {
        "code" : "4186-3",
        "display" : "Somali"
      },
      {
        "code" : "2074-3",
        "display" : "Trinidadian"
      }]
    },
    {
      "system" : "http://ahip.org/demographics/CodeSystem/ahip-demo-additional-background-codes",
      "concept" : [{
        "code" : "9999-5",
        "display" : "Angolan"
      },
      {
        "code" : "9999-6",
        "display" : "Cabo Verdean"
      },
      {
        "code" : "9999-7",
        "display" : "Congolese"
      },
      {
        "code" : "9999-8",
        "display" : "Ghanaian"
      },
      {
        "code" : "9999-9",
        "display" : "Kenyan"
      },
      {
        "code" : "9999-10",
        "display" : "Sudanese"
      }]
    },
    {
      "system" : "http://terminology.hl7.org/CodeSystem/v3-NullFlavor",
      "version" : "4.0.0",
      "concept" : [{
        "code" : "ASKU",
        "display" : "I don't know"
      }]
    },
    {
      "system" : "http://ahip.org/demographics/CodeSystem/AHIP-Demo-Additional-NullFlavor",
      "concept" : [{
        "code" : "CNTR",
        "display" : "I choose not to respond at this time"
      }]
    }]
  }
}

```
