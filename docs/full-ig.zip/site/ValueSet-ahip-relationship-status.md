# AHIP Relationship Status - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **AHIP Relationship Status**

## ValueSet: AHIP Relationship Status 

| | |
| :--- | :--- |
| *Official URL*:http://ahip.org/demographics/ValueSet/ahip-relationship-status | *Version*:0.1.0 |
| Active as of 2026-08-25 | *Computable Name*:AHIPRelationshipStatus |
| **Copyright/Legal**: Used by permission of HL7 International, all rights reserved Creative Commons License | |

 
Used as the answer options for the relationship status question in the SOGI and Relationship Status Section. 

 **References** 

* [AHIP CIVITAS DEMO QUESTIONNAIRE](Questionnaire-AHIPDemoQuestionnaire.md)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "ahip-relationship-status",
  "url" : "http://ahip.org/demographics/ValueSet/ahip-relationship-status",
  "version" : "0.1.0",
  "name" : "AHIPRelationshipStatus",
  "title" : "AHIP Relationship Status",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-08-25T00:00:00-04:00",
  "publisher" : "AHIP",
  "contact" : [{
    "name" : "AHIP",
    "telecom" : [{
      "system" : "url",
      "value" : "http://ahip.org"
    }]
  }],
  "description" : "Used as the answer options for the relationship status question in the SOGI and Relationship Status Section.",
  "copyright" : "Used by permission of HL7 International, all rights reserved Creative Commons License",
  "compose" : {
    "include" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/v3-MaritalStatus",
      "concept" : [{
        "code" : "M",
        "display" : "Married"
      },
      {
        "code" : "D",
        "display" : "Divorced"
      },
      {
        "code" : "L",
        "display" : "Separated"
      },
      {
        "code" : "W",
        "display" : "Widowed"
      },
      {
        "code" : "T",
        "display" : "In a registered domestic partnership"
      },
      {
        "code" : "U",
        "display" : "Single"
      }]
    },
    {
      "system" : "http://ahip.org/demographics/CodeSystem/ahip-demo-additional-relationship-status-codes",
      "concept" : [{
        "code" : "DATI",
        "display" : "Dating (in a non-committed relationship with one person or more than one person)"
      },
      {
        "code" : "MONR",
        "display" : "In a committed relationship with one person but not married (monogamous relationship)"
      },
      {
        "code" : "POLY",
        "display" : "In a committed relationship with more than one person (polyamorous relationship)"
      }]
    },
    {
      "system" : "http://ahip.org/demographics/CodeSystem/AHIP-Demo-Additional-NullFlavor",
      "concept" : [{
        "code" : "PSIN",
        "display" : "Please specify if not listed above"
      },
      {
        "code" : "CNTR",
        "display" : "I choose not to respond at this time"
      }]
    }]
  }
}

```
