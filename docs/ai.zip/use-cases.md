# Use Cases - v0.1.0

* [**Table of Contents**](toc.md)
* **Use Cases**

## Use Cases

# Use Cases

The Questionnaire can be administered by a variety of organizations across the healthcare ecosystem. Providers, for example, may integrate the questions and response choices in the EHRs or as part of their patient portals. Health plans may integrate the information into their enrollment forms, health risk assessments, or as part of their patient applications. Regardless of where the data are collected, given it is a standardized FHIR resource, it can be seamlessly shared among trusted parties. This could include public health agencies, community-based organizations, HIEs, and other stakeholders with a vested interest and role in improving access to and the quality of care.

## Example Use Case: Provider-to-Payer Social and Clinical Needs Exchange

A primary care clinic embeds the standardized Questionnaire (per the Implementation Guide) in its EHR intake workflow and collects patient responses during visits or via the patient portal. The EHR exports a FHIR Questionnaire Response conforming to the IG and transmits it securely to the patient's health plan via a FHIR REST API (or secure HIE) with appropriate consent and patient matching. The payer ingests the structured data to populate enrollment records, track trends by population, offer guidance to provider partners, and target member outreach (care management, SDOH referrals). Because both parties follow the IG, data semantics, validation rules, and versioning are consistent, enabling automated processing, reduced manual follow-up, and auditable exchanges.

## Example Use Case: Provider Using the DEMo Questionnaire During Intake

A healthcare provider incorporates the DEMo FHIR Questionnaire into its patient intake process to collect standardized demographic information directly from patients. The Questionnaire is made available through the patient portal, pre-visit workflow, registration process, or another electronic intake application. Before a health care encounter, the patient is invited to complete the DEMo Questionnaire. The Questionnaire provides a standardized approach to collecting demographic information while allowing patients to provide responses that accurately reflect how they identify. After the patient completes the DEMo Questionnaire, the standardized response options ensure that demographic information is captured consistently while preserving appropriate opportunities for self-identification, including responses such as "prefer not to answer" when applicable. The responses are captured as a FHIR QuestionnaireResponse and demographic information is incorporated into the patient's record. The provider may then use the standardized responses to populate or update appropriate demographic information in the patient's electronic health record and the patient's responses support more culturally competent care delivery. Clinicians and care teams use this demographic information to support patient-centered communication, care planning, identification of disparities, and other clinical or operational workflows. The standardized data can also be used for population health, quality measurement, and disparities analysis.

## Example Use Case: Payer Collecting the DEMo Questionnaire During Enrollment

A health plan incorporates the DEMo FHIR Questionnaire into its member enrollment process to collect standardized demographic information directly from new and existing members. The questionnaire is presented through the plan's member portal, enrollment application, or other digital enrollment workflow.

The questionnaire is presented during enrollment, and as part of the enrollment process, the member is invited to complete the DEMo Questionnaire. The Questionnaire uses standardized questions, response options, and terminology to support consistent collection of demographic information. The member completes the Questionnaire and provides demographic information directly, including the ability to select applicable responses and, where appropriate, indicate that they prefer not to answer or that a particular response does not apply. The member's responses are captured as a FHIR QuestionnaireResponse. The payer's system then creates a structured QuestionnaireResponse linked to the member and the specific version of the DEMo Questionnaire used for data collection. Their responses are incorporated into the member's record, and the payer may use the standardized responses to populate or update demographic information within the member's administrative record. Because this information is collected using a standardized questionnaire, the payer can maintain greater consistency across enrollment channels and reduce reliance on locally defined demographic questions and response options.

